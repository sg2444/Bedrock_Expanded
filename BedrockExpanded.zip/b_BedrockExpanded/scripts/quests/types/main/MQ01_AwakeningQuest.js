import { StageableQuest } from "../../base/StageableQuest.js";
import {
  DimensionEntryObjective,
  ItemCollectionObjective,
  EntityInteractionObjective,
} from "../../objectives/index.js";

export class MQ01_AwakeningQuest extends StageableQuest {
  constructor() {
    super(
      "MQ01",
      "Awakening",
      "You feel a presence stir as you touch the monolith. Memories echo, fractured and faint.",
      "main"
    );
    this.setStage(0);
    this.dialogue = {
      intro: [
        {
          id: "MQ01/intro_vision",
          auto: true,
        },
      ],
      stage: {
        2: [
          {
            npc: "be:kaelin",
            id: "MQ01/seer_intro",
          },
        ],
      },
    };
  }

  defineStage(stage) {
    switch (stage) {
      case 0:
        return [
          new DimensionEntryObjective({
            id: "enterCaveBeneathMonolith",
            questId: this.id,
            dimension: "overworld",
            position: { x: "~", y: "~", z: "~" },
            radius: 12,
            triggerOnce: true,
            description: "Investigate the glow beneath the monolith hill.",
          }),
        ];
      case 1:
        return [
          new ItemCollectionObjective({
            id: "collectCoreFragment",
            questId: this.id,
            itemId: "custom:core_fragment",
            requiredCount: 1,
            description: "Recover the fragment sealed in stone.",
          }),
        ];
      case 2:
        return [
          new EntityInteractionObjective({
            id: "talkToSeerNPC",
            questId: this.id,
            entityTypes: ["be:kaelin"],
            requiresHeldItem: "custom:core_fragment",
            description: "Bring the fragment to the Elder in the village.",
          }),
        ];
      default:
        return [];
    }
  }

  onComplete(player) {
    player.sendMessage(
      "§6[Quest] The Elder nods solemnly. 'You have awakened, but the road ahead remains shadowed.'"
    );
    player.setDynamicProperty("awakeningQuestComplete", true);
  }

  getDescription() {
    return {
      text: `Stage ${this.stage + 1}: ${
        this.objectives[0]?.description ?? "..."
      }`,
    };
  }

  getTitle() {
    return `§e${this.name} §7(Stage ${this.stage + 1}/3)`;
  }

  getActionbar(player) {
    const obj = this.getCurrentObjective(player);
    return {
      text: `§b[Stage ${this.stage + 1}] ${
        obj?.getProgressText?.(player) ?? "..."
      }`,
    };
  }

  serialize(player) {
    return super.serialize?.(player);
  }
  /*   serialize(player) {
    return {
      id: this.id,
      stage: this.stage,
    };
  } */
}
