export const complete = {
  "format_version": "1.19.60",
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        "npc_name": "Elder",
        "text": [
          "You have done well. The world will not forget your name."
        ],
        "buttons": [
          {
            "text": "Finish",
            "commands": []
          }
        ]
      }
    }
  }
};