import g1 from "./generic_1.js";
import g2 from "./generic_2.js";
import g3 from "./generic_3.js";
import g4 from "./generic_4.js";
import g5 from "./generic_5.js";

export const Generic_Dialogues = [
  { id: "default.generic_1", data: g1 },
  { id: "default.generic_2", data: g2 },
  { id: "default.generic_3", data: g3 },
  { id: "default.generic_4", data: g4 },
  { id: "default.generic_5", data: g5 },
];
