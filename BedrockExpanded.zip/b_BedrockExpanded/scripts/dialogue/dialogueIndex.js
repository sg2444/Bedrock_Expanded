import { Quest_Dialogues } from "./quests/_index.js";
import { Generic_Dialogues } from "./default/_index.js";

export const dialogueIndex = [...Quest_Dialogues, ...Generic_Dialogues];
