export const stage2 = {
  "format_version": "1.19.60",
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        "npc_name": "Kaelin",
        "text": [
          "You must now step through and face what lies beyond."
        ],
        "buttons": [
          {
            "text": "Understood",
            "commands": []
          }
        ]
      }
    }
  }
};