export const intro_vision = {
  format_version: "1.19.60",
  "minecraft:dialogue": {
    scenes: {
      start: {
        npc_name: "???",
        text: [
          "You hear whispers echo through the void...",
          "Fragments of a forgotten purpose surface in your mind.",
        ],
        buttons: [{ text: "..." }],
      },
    },
  },
};
