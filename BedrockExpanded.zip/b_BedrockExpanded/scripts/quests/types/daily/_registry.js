
//import


export const dailyQuests = [
    
  ];