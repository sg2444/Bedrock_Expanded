export default {
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        npc_name: "Wandering Villager",
        text: ['Even the quietest paths can lead to great stories.', 'What tale will yours become?'],
        buttons: [{'text': 'Reflect silently.', 'commands': []}, {'text': 'Say goodbye.', 'commands': []}]
      }
    }
  }
};
