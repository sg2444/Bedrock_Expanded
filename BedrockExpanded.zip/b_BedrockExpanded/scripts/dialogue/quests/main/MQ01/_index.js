import { intro_vision } from "./intro.js";
import { seer_intro } from "./seer_intro.js";

export const MQ01_Dialogues = [
  { id: "MQ01/intro_vision", data: intro_vision },
  { id: "MQ01/seer_intro", data: seer_intro },
];
