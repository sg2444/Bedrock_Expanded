export const intro = {
  "format_version": "1.19.60",
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        "npc_name": "Kaelin",
        "text": [
          "Welcome, traveler. Your journey begins here."
        ],
        "buttons": [
          {
            "text": "OK",
            "commands": []
          }
        ]
      }
    }
  }
};