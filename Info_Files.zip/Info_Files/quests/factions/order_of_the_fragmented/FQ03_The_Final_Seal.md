# FQ03: The Final Seal

## Faction: Order of the Fragmented
## Summary:
The final glyph site lies dormant but intact. The Order plans to purge it with a relic bomb. You are asked to guard the team—but a whisper from the Echo tempts you to sabotage the mission.

## Objectives:
1. Reach the final glyph chamber.
2. Guard or sabotage the explosive placement.
3. Survive Echo Cult retaliation.
4. Decide to preserve or erase the glyph node.

## Rewards:
- 700 XP
- Fragmented Emblem (faction cosmetic)
- Permanent faction alignment (Seal Path)

