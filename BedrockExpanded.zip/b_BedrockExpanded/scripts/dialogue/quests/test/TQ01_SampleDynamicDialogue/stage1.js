export const stage1 = {
  "format_version": "1.19.60",
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        "npc_name": "Gerren",
        "text": [
          "Ah, you brought what I asked. Let's move forward."
        ],
        "buttons": [
          {
            "text": "OK",
            "commands": []
          }
        ]
      }
    }
  }
};