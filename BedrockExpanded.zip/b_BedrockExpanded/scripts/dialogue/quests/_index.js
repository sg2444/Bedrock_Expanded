import { MQ_Dialogues } from "./main/_index.js";
import { TQ_Dialogues } from "./test/_index.js";

export const Quest_Dialogues = [...MQ_Dialogues, ...TQ_Dialogues];
