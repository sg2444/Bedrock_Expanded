# FQ02: The Split Soul

## Summary:
A rift within the Echo Plane mimics your identity. The Echobound believe you must confront your **Echo Self** and “decide who carries the name.”

## Objectives:
1. Enter the rift gate in the Echo Plane.  
2. Complete a puzzle reflection trial (solve a scene from MQ05 backward).  
3. Fight your Echo Self in a duel.  
4. Choose to absorb or release the shadow.

## Rewards:
- 600 XP  
- *Echo Sigil Ring*  
- Choice affects voice lines and future MQ epilogue

## Notes:
- Absorbing enhances Dreamwalker resonance  
- Releasing earns Whisperer faction favor
