export default {
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        npc_name: "Wandering Villager",
        text: ['The stars shine bright tonight.', 'A good omen, perhaps?'],
        buttons: [{'text': 'Look up in wonder.', 'commands': []}, {'text': 'Say nothing.', 'commands': []}]
      }
    }
  }
};
