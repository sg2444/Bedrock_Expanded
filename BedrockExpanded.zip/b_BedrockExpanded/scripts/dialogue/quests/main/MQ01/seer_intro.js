export const seer_intro = {
  format_version: "1.19.60",
  "minecraft:dialogue": {
    scenes: {
      start: {
        npc_name: "Seer",
        text: [
          "The core fragment... you've returned it.",
          "You must understand what comes next.",
        ],
        buttons: [{ text: "I'm ready." }],
      },
    },
  },
};
