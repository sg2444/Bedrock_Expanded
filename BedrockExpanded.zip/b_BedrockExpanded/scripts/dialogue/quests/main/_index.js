import { MQ01_Dialogues } from "./MQ01/_index.js";

export const MQ_Dialogues = [...MQ01_Dialogues];
