import { MQ01_AwakeningQuest } from "./MQ01_AwakeningQuest.js";

export const mainQuests = [{ id: "MQ01", class: MQ01_AwakeningQuest }];
