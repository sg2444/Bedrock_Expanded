export const stage0 = {
  "format_version": "1.19.60",
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        "npc_name": "Villager",
        "text": [
          "I need some apples. Can you gather them for me?"
        ],
        "buttons": [
          {
            "text": "Sure!",
            "commands": []
          }
        ]
      }
    }
  }
};