import { TQ01_Dialogues } from "./TQ01_SampleDynamicDialogue/_index.js";

export const TQ_Dialogues = [...TQ01_Dialogues];
