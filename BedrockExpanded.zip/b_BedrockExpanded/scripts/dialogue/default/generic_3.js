export default {
  "minecraft:dialogue": {
    "scenes": {
      "start": {
        npc_name: "Wandering Villager",
        text: ['You carry the scent of faraway places.', 'Have you seen the desert temples?'],
        buttons: [{'text': 'Not yet.', 'commands': ['say Then you’ve much to explore.']}, {'text': 'Stay silent.', 'commands': []}]
      }
    }
  }
};
